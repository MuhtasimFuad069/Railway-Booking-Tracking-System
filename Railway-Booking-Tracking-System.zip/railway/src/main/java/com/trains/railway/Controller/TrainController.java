package com.trains.railway.Controller;

import com.trains.railway.Entity.Train;
import com.trains.railway.Service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
//@RequestMapping("/api/trains")
public class TrainController {

    @Autowired
    private TrainService trainService;

    private final Logger LOGGER = LoggerFactory.getLogger(TrainController.class);

    @PostMapping("/trains")
    public String saveTrain(@RequestBody Train train) {
        LOGGER.info("Train saved to database");
        trainService.saveTrain(train);
        return "Train Created Successfully!!";

    }

    @GetMapping("/trains")
    public List<Train> getAllTrains() {
        LOGGER.info("Get all trains from database");
        return trainService.getAllTrains();
    }

    @GetMapping("/trains/{id}")
    public Train getTrainById(@PathVariable("id") Long trainId) {
        return trainService.getTrainById(trainId);
    }

    @PutMapping("/trains/{id}")
    public Train updateTrain(@PathVariable("id") Long trainId, @RequestBody Train train) {
        return trainService.updateTrain(trainId, train);
    }

    @DeleteMapping("/trains/{id}")
    public String deleteTrainById(@PathVariable("id") Long trainId) {
        trainService.deleteTrainById(trainId);
        return "Train successfully deleted";
    }
}
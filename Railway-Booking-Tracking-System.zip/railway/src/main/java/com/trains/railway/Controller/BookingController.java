package com.trains.railway.Controller;

import com.trains.railway.Entity.Booking;
import com.trains.railway.Service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

//import java.util.Date;
import java.util.List;

@RestController
//@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    private final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);

    @PostMapping("/bookings")
    public String saveBooking(@RequestBody Booking booking) {
        LOGGER.info("Booking saved to database");
        bookingService.saveBooking(booking);
        return "Booking made successfully!!";
    }

    @GetMapping("/bookings")
    public List<Booking> getAllBookings() {
        LOGGER.info("Get all bookings from database");
        return bookingService.getAllBookings();
    }

    @GetMapping("/bookings/{id}")
    public Booking getBookingById(@PathVariable ("id") Long bookingId) {
        return bookingService.getBookingById(bookingId);
    }

    @PutMapping("/bookings/{id}")
    public Booking updateBooking(@PathVariable ("id") Long bookingId, @RequestBody Booking booking) {
        return bookingService.updateBooking(bookingId, booking);
    }

    @GetMapping("/bookings/passengerName/{passengerName}")
    public Booking getBookingByPassengerName(@PathVariable ("passengerName") String passengerName) {
        return bookingService.getBookingByPassengerName(passengerName);
    }

    @GetMapping("/bookings/trainId/{trainId}")
    public Booking getBookingByTrainId(@PathVariable ("trainId") Long trainId) {
        return bookingService.getBookingByTrainId(trainId);
    }

//    @GetMapping("/bookings/bookingDate/{bookingDate}")
//    public Date getBookingByBookingDate(@PathVariable ("bookingDate") String bookingDate) {
//        return bookingService.getBookingByBookingDate(bookingDate);
//    }

    @DeleteMapping("/bookings/{id}")
    public String deleteBookingById(@PathVariable ("id") Long bookingId) {
        bookingService.deleteBookingById(bookingId);
        return "Booking successfully deleted";
    }
}
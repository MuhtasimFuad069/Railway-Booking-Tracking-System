package com.trains.railway.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.validation.constraints.*;
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.hibernate.validator.constraints.Length;


@Entity
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
public class Train {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long trainId;
    private String name;
    private String origin;
    private String destination;
    private int availableSeats;

    //@NotBlank(message = "Please Add Train Name")
    //@Length
    //@Size
    //@Email
    //@Positive
    //@Negative
    //@PositiveOrZero
    //@NegativeOrZero
    //@Future
    //@FutureOrPresent
    //@Past
    //@PastOrPresent

    public Train(String origin, String destination, int availableSeats) {
        this.origin = origin;
        this.destination = destination;
        this.availableSeats = availableSeats;
    }

    public Train() {
    }

    @Override
    public String toString() {
        return "Train{"  +
                "trainId=" + trainId +
                ",  name='" + name + '\'' +
                ",  origin='" + origin + '\'' +
                ",  destination='" + destination + '\'' +
                ",  availableSeats='" + availableSeats + '\'' + '}';
    }

    public Long getTrainId() {
        return trainId;
    }

    public void setTrainId(Long trainId) {
        this.trainId = trainId;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Train(Long trainId, String name, String origin, String destination, int availableSeats) {
        this.trainId = trainId;
        this.name = name;
        this.origin = origin;
        this.destination = destination;
        this.availableSeats = availableSeats;
    }
}

package com.trains.railway.Repository;

import com.trains.railway.Entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    Booking findByBookingId(Long bookingId);

    public Booking findByPassengerName(String passengerName);

    public Booking findByTrainId(Long trainId);

    public Booking findByBookingDate(Date bookingDate);

    public Booking findByPassengerNameIgnoreCase(String passengerName);
}
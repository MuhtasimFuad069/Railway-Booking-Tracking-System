package com.trains.railway.Repository;

import com.trains.railway.Entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {
    public Train findByName(String name);

    Train findByTrainId(Long trainId);

    public Train findByOrigin(String origin);

    public Train findByDestination(String destination);

    public Train findByNameIgnoreCase(String name);

    public Train findByAvailableSeats(int availableSeats);
}
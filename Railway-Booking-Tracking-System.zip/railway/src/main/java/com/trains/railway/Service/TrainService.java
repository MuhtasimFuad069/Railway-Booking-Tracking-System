package com.trains.railway.Service;

import com.trains.railway.Entity.Train;
//import com.trains.railway.Repository.TrainRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TrainService {
    public Train saveTrain(Train train);

    public List<Train> getAllTrains();

    void deleteTrainById(Long trainId);

    public Train getTrainById(Long trainId);

    public Train getTrainByName(String name);

    public Train getTrainByOrigin(String origin);

    public Train getTrainByDestination(String destination);

    Train updateTrain(Long trainId, Train train);
}

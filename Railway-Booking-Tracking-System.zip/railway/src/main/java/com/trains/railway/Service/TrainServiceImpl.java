package com.trains.railway.Service;

import com.trains.railway.Entity.Train;
import com.trains.railway.Repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Objects;

@Service
public class TrainServiceImpl implements TrainService {
    @Autowired
    private TrainRepository trainRepository;
    @Override
    public Train saveTrain(Train train) {
        return trainRepository.save(train);
    }

    @Override
    public Train getTrainById(Long trainId) {
        return trainRepository.findById(trainId).get();
    }

    // @Override
    // public Train getTrainByAvailableSeats(int availableSeats) {
    //     return trainRepository.findByAvailableSeats(availableSeats).get();
    // }

    @Override
    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    @Override
    public void deleteTrainById(Long trainId) {
        trainRepository.deleteById(trainId);
    }

    @Override
    public Train getTrainByName(String Name) {
        return trainRepository.findByNameIgnoreCase(Name);
    }

    @Override
    public Train getTrainByOrigin(String origin) {
        return trainRepository.findByOrigin(origin);
    }

    @Override
    public Train getTrainByDestination(String destination) {
        return trainRepository.findByDestination(destination);
    }

    @Override
    public Train updateTrain(Long trainId, Train train) {
        Train railDB = trainRepository.findById(trainId).get();

        if(Objects.nonNull(train.getName())  && !"".equalsIgnoreCase(train.getName())) {
            railDB.setName(train.getName());
        }
        if(Objects.nonNull(train.getOrigin())  && !"".equalsIgnoreCase(train.getOrigin())) {
           railDB.setOrigin(train.getOrigin());
        }
        if(Objects.nonNull(train.getDestination())  && !"".equalsIgnoreCase(train.getDestination())) {
        railDB.setDestination(train.getDestination());
        }
        return trainRepository.save(railDB);
    }
}
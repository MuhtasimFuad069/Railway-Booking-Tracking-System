package com.trains.railway.Service;

import com.trains.railway.Entity.Booking;
//import com.trains.railway.Entity.Train;
//import com.trains.railway.Repository.BookingRepository;
//import com.trains.railway.Repository.TrainRepository;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public interface BookingService {
    public Booking saveBooking(Booking booking);

    public Booking getBookingById(Long bookingId);

    public List<Booking> getAllBookings();

    void deleteBookingById(Long bookingId);

    public Booking getBookingByPassengerName(String passengerName);

    public Booking getBookingByTrainId(Long trainId);

    public Booking getBookingByBookingDate(Date bookingDate);

    Booking updateBooking(Long bookingId, Booking booking);
}

package com.trains.railway.Service;

import com.trains.railway.Entity.Booking;
//import com.trains.railway.Entity.Train;
import com.trains.railway.Repository.BookingRepository;
//import com.trains.railway.Repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class BookingServiceImpl implements BookingService {
    @Autowired
    private BookingRepository bookingRepository;
    @Override
    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public Booking getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId).get();
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

//    @Override
//    public Booking getBookingById(Long id) {
//        return bookingRepository.findById(id);
//    }

    @Override
    public void deleteBookingById(Long bookingId) {
        bookingRepository.deleteById(bookingId);
    }

    @Override
    public Booking getBookingByPassengerName(String passengerName) {
        return bookingRepository.findByPassengerNameIgnoreCase(passengerName);
    }

    @Override
    public Booking getBookingByTrainId(Long trainId) {
        return bookingRepository.findByTrainId(trainId);
    }

    @Override
    public Booking getBookingByBookingDate(Date bookingDate) {
        return bookingRepository.findByBookingDate(bookingDate);
    }

    @Override
    public Booking updateBooking(Long bookingId, Booking booking) {
        Booking railDB = bookingRepository.findById(bookingId).get();

        if(Objects.nonNull(booking.getPassengerName())  && !"".equalsIgnoreCase(booking.getPassengerName())) {
            railDB.setPassengerName(booking.getPassengerName());
        }
//        if(Objects.nonNull(booking.getBookingDate())  && !"".equalsIgnoreCase(booking.getBookingDate())) {
//            railDB.setBookingDate(booking.getBookingDate());
//        }

        return bookingRepository.save(railDB);
    }

//    @Override
//    public Booking updateBooking(Long Id, Booking booking) {
//        Booking railDB = bookingRepository.findById(Id).get();
//
//        if(Objects.nonNull(booking.getPassengerName()) && !"".equalsIgnoreCase(booking.getPassengerName())) {
//            railDB.setPassengerName(booking.getPassengerName());
//        }
//        if(Objects.nonNull(booking.getBookingDate()) && !"".equalsIgnoreCase(booking.getBookingDate())) {
//            railDB.setBookingDate(booking.getBookingDate());
//        }
//        if(Objects.nonNull(booking.getTrainId()) && !"".equalsIgnoreCase(booking.getTrainId())) {
//            railDB.setTrainId(booking.getTrainId());
//        }
//
//        return bookingRepository.save(railDB);
//    }


//    public Booking createBooking(String passengerName, Long trainId) {
//        Train train = trainRepository.findById(trainId).orElseThrow(() -> new RuntimeException("Train not found"));
//
//        if (train.getAvailableSeats() <= 0) {
//            throw new RuntimeException("No seats available");
//        }
//
//        train.setAvailableSeats(train.getAvailableSeats() - 1);
//        trainRepository.save(train);
//
//        Booking booking = new Booking();
//        booking.setPassengerName(passengerName);
//        booking.setTrainId(trainId);
//        booking.setBookingDate(new Date());
//
//        return bookingRepository.save(booking);
//    }
}
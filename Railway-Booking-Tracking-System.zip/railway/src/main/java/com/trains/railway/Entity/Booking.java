package com.trains.railway.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.validation.constraints.*;
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.hibernate.validator.constraints.Length;
import java.util.Date;

@Entity
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;
    private String passengerName;
    private Long trainId;
    private Date bookingDate;

    //@NotBlank(message = "Please Add Department Name")
    //@Length
    //@Size
    //@Email
    //@Positive
    //@Negative
    //@PositiveOrZero
    //@NegativeOrZero
    //@Future
    //@FutureOrPresent
    //@Past
    //@PastOrPresent

    public Booking(Long trainId, Date bookingDate) {
        this.trainId = trainId;
        this.bookingDate = bookingDate;
    }

    public Booking() {
    }

    @Override
    public String toString() {
        return "Booking{" +
                "id="  + bookingId  +
                ",  passengerName='"  +  passengerName  +  '\''  +
                ",  trainId='"  +  trainId  +  '\''  +
                ",  bookingDate='"  +  bookingDate  +  '\''  +  '}';
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public Long getTrainId() {
        return trainId;
    }

    public void setTrainId(Long trainId) {
        this.trainId = trainId;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date date) {
        this.bookingDate = date;
    }

    public Booking(Long bookingId, String passengerName, Long trainId, Date bookingDate) {
        this.bookingId = bookingId;
        this.passengerName = passengerName;
        this.trainId = trainId;
        this.bookingDate = bookingDate;
    }
}